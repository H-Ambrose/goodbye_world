# TweetsAnalysis_Suicide
Group Project for NU CE510 Social Media Mining

Video Tutorial: https://www.youtube.com/watch?v=wlnx-7cm4Gg

Tweepy Documentation: http://docs.tweepy.org/en/latest/
